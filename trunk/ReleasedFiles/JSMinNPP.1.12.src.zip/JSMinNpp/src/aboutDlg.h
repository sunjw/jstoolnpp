#ifndef _ABOUT_DLG_H_
#define _ABOUT_DLG_H_
#include "PluginInterface.h"
#include "menuCmdID.h"

void projectSite();

BOOL CALLBACK dlgProcAbout(HWND hwnd, UINT message, WPARAM wParam, LPARAM lParam);

#endif
