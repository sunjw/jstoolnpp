#ifndef _COMMON_DEF_H_
#define _COMMON_DEF_H_

#define PLUGIN_NAME "&JSMin"
#define PROJECT_SITE "http://jsminnpp.sourceforge.net"
#define CHECK_UPDATE "http://jsminnpp.sourceforge.net/download.php"
#define DONATION "http://sourceforge.net/donate/index.php?group_id=351223"

#endif