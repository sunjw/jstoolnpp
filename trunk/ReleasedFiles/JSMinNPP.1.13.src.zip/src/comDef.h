#ifndef _COMMON_DEF_H_
#define _COMMON_DEF_H_

#define PLUGIN_NAME "&JSMin"
#define PROJECT_SITE "http://www.sunjw.us/jsminnpp/"
#define CHECK_UPDATE "http://www.sunjw.us/jsminnpp/download.php"
#define DONATION "https://www.paypal.com/cgi-bin/webscr?cmd=_donations&business=sunjw8888%40yahoo%2ecom%2ecn&item_name=JSMinNpp%20Project&no_shipping=1&cn=Optional%20comments&tax=0&currency_code=USD&lc=US&amount=1.8&bn=PP%2dDonationsBF&charset=UTF%2d8"

#endif